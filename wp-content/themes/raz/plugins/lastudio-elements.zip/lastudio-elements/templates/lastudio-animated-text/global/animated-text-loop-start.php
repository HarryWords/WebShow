<?php
/**
 * Animated text list start template
 */
?>
<div class="lastudio-animated-text__animated-text">
