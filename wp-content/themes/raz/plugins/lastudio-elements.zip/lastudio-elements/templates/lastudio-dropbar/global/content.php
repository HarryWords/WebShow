<?php
/**
 * Dropbar content template
 */
?>
<div class="lastudio-dropbar__content-wrapper">
	<div class="lastudio-dropbar__content"><?php
		echo $this->get_dropbar_content();
	?></div>
</div>