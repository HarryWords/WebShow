<div class="lastudio-progress-bar__inner">
	<div class="lastudio-progress-bar__wrapper">
		<div class="lastudio-progress-bar__status-bar"></div>
		<div class="lastudio-progress-bar__status">
			<div class="lastudio-progress-bar__percent"><span class="lastudio-progress-bar__percent-value">0</span><span class="lastudio-progress-bar__percent-suffix">&#37;</span></div>
			<div class="lastudio-progress-bar__title"><?php
				$this->__html( 'icon', '<i class="lastudio-progress-bar__title-icon %s"></i>' );
				$this->__html( 'title', '<span class="lastudio-progress-bar__title-text">%s</span>' );?></div>
		</div>
	</div>
</div>
